---
name: what-is-testdriver
description: Reliably test your most difficult user flows
---
<!-- Generated from what-is-testdriver.mdx. DO NOT EDIT. -->

## The problem with modern testing tools

Modern testing tools like Playwright are designed to test a single web application, running in a single browser tab using selectors.

However, selectors are often either unreliable or unavailable in complex scenarios, leading to brittle and flaky tests:

| Challenge | Problem | Examples |
|-----------|---------|----------|
| **Fast moving teams** | Frequently change UI structure, breaking CSS/XPath selectors | Agile teams, startups, vibe-coders |
| **Dynamic content** | Cannot be targeted with selectors | AI chatbots, PDFs, images, videos |
| **Software you don't own** | May lack proper accessibility attributes | Other websites, extensions, third-party applications |
| **Multi-application workflows** | Cannot be tested with web-only tools | Desktop apps, browser extensions, IDEs |
| **Visual states** | Impossible to verify with code-based selectors | Charts, graphs, videos, images, spelling errors, UI layout |

## The TestDriver Solution

TestDriver is a complete testing platform built specifically for handling these scenarios. It consists of a Javascript SDK, hosted infrastructure, and debugging tools that make it easy to write, run, and maintain tests for your most difficult user flows.

### Javascript SDK

Here is an example of a TestDriver test that installs a production Chrome extension from the Chrome Web Store and verifies that it appears in the extensions menu:

```javascript Installing Loom from the Chrome Web Store
import { describe, expect, it } from "vitest";
import { TestDriver } from "testdriverai/vitest/hooks";

describe("Chrome Extension Test", () => {
  const testdriver = TestDriver(context);

  // Launch Chrome with Loom loaded by its Chrome Web Store ID
  await testdriver.provision.chromeExtension({
    extensionId: 'liecbddmkiiihnedobmlmillhodjkdmb'
  });

  // Click on the extensions button (puzzle piece icon) in Chrome toolbar
  const extensionsButton = await testdriver.find("The puzzle-shaped icon in the Chrome toolbar.");
  await extensionsButton.click();

  // Look for Loom in the extensions menu
  const loomExtension = await testdriver.find("Loom extension in the extensions dropdown");
  expect(loomExtension.found()).toBeTruthy();
});
```


<Tip>[vitest](https://vitest.dev/) is the preferred test runner for TestDriver.</Tip>

,
