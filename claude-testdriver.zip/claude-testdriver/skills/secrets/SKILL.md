---
name: secrets
description: Securely manage passwords and sensitive data in your tests
---
<!-- Generated from secrets.mdx. DO NOT EDIT. -->

Protect sensitive information like passwords, API keys, and tokens in your TestDriver tests.

## Typing Secrets Securely

When typing sensitive information like passwords, use the `secret: true` option to prevent the value from being logged or stored:

```javascript
import { test } from 'vitest';
import { chrome } from 'testdriverai/presets';

test('login with secure password', async (context) => {
  const { testdriver } = await chrome(context, { 
    url: 'https://myapp.com/login' 
  });

  await testdriver.find('email input').click();
  await testdriver.type(process.env.TD_USERNAME);
  
  await testdriver.find('password input').click();
  // Password is masked in logs and recordings
  await testdriver.type(process.env.TD_PASSWORD, { secret: true });
  
  await testdriver.find('login button').click();
  await testdriver.assert('dashboard is visible');
});
```

<Note>
When `secret: true` is set, the typed text appears as `****` in all logs, recordings, and dashcam output.
</Note>

## Storing Secrets in GitHub

Store sensitive credentials as GitHub repository secrets so they're never exposed in your code:

<Steps>
  <Step title="Navigate to Repository Settings">
    Go to your GitHub repository → **Settings** → **Secrets and variables** → **Actions**
  </Step>
  <Step title="Add Repository Secrets">
    Click **New repository secret** and add your secrets:
    - `TD_API_KEY` - Your TestDriver API key
    - `TD_USERNAME` - Test account username
    - `TD_PASSWORD` - Test account password
  </Step>
  <Step title="Use in GitHub Actions">
    Reference secrets in your workflow file:
    ```yaml .github/workflows/test.yml
    - name: Run TestDriver tests
      env:
        TD_API_KEY: ${{ secrets.TD_API_KEY }}
        TD_USERNAME: ${{ secrets.TD_USERNAME }}
        TD_PASSWORD: ${{ secrets.TD_PASSWORD }}
      run: npx vitest run
    ```
  </Step>
</Steps>

## Local Development

For local development, store secrets in a `.env` file:

```bash .env
TD_API_KEY=your_api_key_here
TD_USERNAME=testuser@example.com
TD_PASSWORD=your_secure_password
```

<Warning>
Never commit `.env` files to version control. Add `.env` to your `.gitignore` file.
</Warning>

## Complete Example

Here's a full login test with proper secrets handling:

```javascript tests/login.test.js
import { test, expect } from 'vitest';
import { chrome } from 'testdriverai/presets';

test('secure login flow', async (context) => {
  const { testdriver } = await chrome(context, { 
    url: process.env.TD_WEBSITE || 'https://staging.myapp.com'
  });

  // Enter username (not sensitive)
  await testdriver.find('email input').click();
  await testdriver.type(process.env.TD_USERNAME);
  
  // Enter password securely
  await testdriver.find('password input').click();
  await testdriver.type(process.env.TD_PASSWORD, { secret: true });
  
  // Submit login
  await testdriver.find('login button').click();
  
  // Verify successful login
  const loggedIn = await testdriver.assert('user is logged in');
  expect(loggedIn).toBeTruthy();
});
```

<Card title="Secrets Best Practices" icon="shield-check">
  - **Always use `secret: true`** when typing passwords, tokens, or sensitive data
  - **Use environment variables** to keep secrets out of code
  - **Store secrets in your CI provider** (GitHub Actions, GitLab CI, etc.)
  - **Never commit secrets** to version control
  - **Rotate secrets regularly** to maintain security
</Card>
