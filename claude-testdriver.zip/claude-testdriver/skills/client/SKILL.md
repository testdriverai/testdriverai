---
name: client
description: Initialize and configure the TestDriver SDK client
---
<!-- Generated from client.mdx. DO NOT EDIT. -->

## Overview

The `TestDriver` client is the main entry point for the SDK. It handles authentication, sandbox connection, and provides access to all testing methods.

## Constructor

```javascript
const testdriver = new TestDriver(apiKey, options)
```

### Parameters

<ParamField path="apiKey" type="string" required>
  Your TestDriver API key from the [dashboard](https://console.testdriver.ai/team)
</ParamField>

<ParamField path="options" type="object">
  Configuration options for the client
  
  <Expandable title="properties">
    <ParamField path="os" type="string" default="windows">
      Operating system for the sandbox: `'windows'` or `'linux'`
    </ParamField>
    
    <ParamField path="resolution" type="string" default="1366x768">
      Screen resolution for the sandbox (e.g., `'1920x1080'`, `'1366x768'`)
    </ParamField>
    
    <ParamField path="apiRoot" type="string" default="https://testdriver-api.onrender.com">
      API endpoint URL (typically only changed for self-hosted deployments)
    </ParamField>
    
    <ParamField path="analytics" type="boolean" default="true">
      Enable or disable usage analytics
    </ParamField>
    
    <ParamField path="logging" type="boolean" default="true">
      Enable or disable console logging
    </ParamField>
    
    <ParamField path="environment" type="object">
      Additional environment variables to pass to the sandbox
    </ParamField>
  </Expandable>
</ParamField>

### Example

```javascript
import TestDriver from 'testdriverai';

const testdriver = new TestDriver(process.env.TD_API_KEY, {
  os: 'windows',
  resolution: '1920x1080',
  logging: true,
  analytics: true
});
```

## Authentication

### auth()

Authenticate with the TestDriver API.

```javascript
await testdriver.auth()
```

**Returns:** `Promise<string>` - Authentication token

**Example:**
```javascript
await testdriver.auth();
```

<Note>
  You must call `auth()` before `connect()`. Most examples call both sequentially.
</Note>

## Connection Management

### connect()

Connect to a sandbox environment. This creates or reconnects to a virtual machine where your tests will run.

```javascript
await testdriver.connect(options)
```

#### Parameters

<ParamField path="options" type="object">
  Connection options
  
  <Expandable title="properties">
    <ParamField path="newSandbox" type="boolean" default="false">
      Force creation of a new sandbox instead of reusing an existing one
    </ParamField>
    
    <ParamField path="sandboxId" type="string">
      Existing sandbox ID to reconnect to
    </ParamField>
    
    <ParamField path="ip" type="string">
      Direct IP address to connect to (for self-hosted sandboxes)
    </ParamField>
    
    <ParamField path="sandboxAmi" type="string">
      AMI to use for the sandbox (AWS deployments)
    </ParamField>
    
    <ParamField path="sandboxInstance" type="string">
      Instance type for the sandbox (AWS deployments)
    </ParamField>
    
    <ParamField path="headless" type="boolean" default="false">
      Run in headless mode without opening the debugger
    </ParamField>
  </Expandable>
</ParamField>

**Returns:** `Promise&lt;Object&gt;` - Sandbox instance details including `instanceId`, `ip`, `vncPort`, etc.

#### Examples

**Basic connection:**
```javascript
await testdriver.connect();
```

**Reconnect to existing sandbox:**
```javascript
const instance = await testdriver.connect({ 
  sandboxId: 'existing-sandbox-id-123' 
});
```

**Self-hosted sandbox:**
```javascript
await testdriver.connect({ 
  ip: '192.168.1.100'
});
```

### disconnect()

Disconnect from the sandbox and clean up resources.

```javascript
await testdriver.disconnect()
```

**Returns:** `Promise<void>`

**Example:**
```javascript
afterAll(async () => {
  await testdriver.disconnect();
});
```

## Instance Information

### getInstance()

Get the current sandbox instance details.

```javascript
const instance = testdriver.getInstance()
```

**Returns:** `Object | null` - Sandbox instance information

**Example:**
```javascript
const instance = testdriver.getInstance();
console.log('Instance ID:', instance.instanceId);
console.log('IP Address:', instance.ip);
```

### getSessionId()

Get the current session ID for tracking and debugging.

```javascript
const sessionId = testdriver.getSessionId()
```

**Returns:** `string | null` - Session ID

**Example:**
```javascript
const sessionId = testdriver.getSessionId();
console.log('Session:', sessionId);
```

## Logging & Events

### setLogging()

Enable or disable console logging at runtime.

```javascript
testdriver.setLogging(enabled)
```

**Parameters:**
- `enabled` (boolean) - Whether to enable logging

**Example:**
```javascript
// Disable logging for cleanup operations
testdriver.setLogging(false);
await testdriver.disconnect();
testdriver.setLogging(true);
```

### getEmitter()

Get the event emitter for custom event handling.

```javascript
const emitter = testdriver.getEmitter()
```

**Returns:** `EventEmitter2` - Event emitter instance

**Example:**
```javascript
const emitter = testdriver.getEmitter();

emitter.on('command:start', (data) => {
  console.log('Command started:', data);
});

emitter.on('command:success', (data) => {
  console.log('Command succeeded:', data);
});

emitter.on('command:error', (error) => {
  console.error('Command failed:', error);
});
```

## Complete Example

```javascript
import { beforeAll, afterAll, describe, it } from 'vitest';
import TestDriver from 'testdriverai';

describe('My Test Suite', () => {
  let testdriver;

  beforeAll(async () => {
    // Initialize client
    client = new TestDriver(process.env.TD_API_KEY, {
      os: 'windows',
      resolution: '1366x768',
      logging: true
    });
    
    // Set up event listeners
    const emitter = testdriver.getEmitter();
    emitter.on('log:info', (msg) => console.log('[INFO]', msg));
    
    // Authenticate and connect
    await testdriver.auth();
    const instance = await testdriver.connect();
    
    console.log('Connected to sandbox:', instance.instanceId);
  });

  afterAll(async () => {
    await testdriver.disconnect();
  });

  it('runs a test', async () => {
    // Your test code here
  });
});
```

## Best Practices

<AccordionGroup>
  <Accordion title="Reuse sandboxes across tests">
    Use `beforeAll`/`afterAll` to create one sandbox per test suite rather than per test. This significantly reduces execution time.
  </Accordion>
  
  <Accordion title="Handle connection errors gracefully">
    Wrap `connect()` in a try-catch block to handle network issues or quota limits:
    
    ```javascript
    try {
      await testdriver.connect();
    } catch (error) {
      console.error('Failed to connect:', error.message);
      throw error;
    }
    ```
  </Accordion>
  
  <Accordion title="Always disconnect">
    Use `afterAll` or try-finally blocks to ensure `disconnect()` is called even if tests fail. This prevents orphaned sandboxes.
  </Accordion>
  
  <Accordion title="Use environment variables for API keys">
    Never hardcode API keys. Use environment variables:
    
    ```javascript
    const testdriver = new TestDriver(process.env.TD_API_KEY);
    ```
  </Accordion>
</AccordionGroup>
